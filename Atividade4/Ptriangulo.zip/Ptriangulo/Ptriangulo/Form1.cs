﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double A, B, C;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ( !double.TryParse(txtValA.Text, out A) ||
             !double.TryParse(txtValB.Text, out B) ||
             !double.TryParse(txtValC.Text, out C))
            {
                MessageBox.Show("Erro: Os vlores devem ser numéricos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (A < (B + C) && A > Math.Abs(B - C) && B < (A + C) &&
                    B > Math.Abs(A - C) && C < (A + C) && C < (A + B) && C > Math.Abs(A - B))
                {
                    if (A == B && B == C)
                    {
                        MessageBox.Show(" Triângulo equilátero");
                    }
                    else
                    {
                        if (A == B || A == C || C == B)
                        {
                            MessageBox.Show(" Triângulo isósceles");
                        }
                        else
                        {
                            MessageBox.Show(" Triângulo escaleno");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Erro: Os valores informados não formam um triângulo", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

            private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValA.Clear();
            txtValB.Clear();
            txtValC.Clear();

            txtValA.Focus();
        }

        
    }
}
