﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenus
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRmvOcorrencias_Click(object sender, EventArgs e) // remove as ocorrências
        {
            int posicao = 0;
            txtPalavra1.Text = txtPalavra1.Text.ToUpper();
            txtPalavra2.Text = txtPalavra2.Text.ToUpper();
            posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text);

            while (posicao >= 0) // busca indexof inicia em 0
            {
                txtPalavra2.Text = txtPalavra2.Text.Substring(0, posicao) +
                txtPalavra2.Text.Substring(posicao + txtPalavra1.Text.Length,
                txtPalavra2.Text.Length - posicao - txtPalavra1.Text.Length);

                posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            }
        }

        private void btnRmvOcorrenciasRpc_Click(object sender, EventArgs e) // remove as ocorrências com o uso do replace
        {
            txtPalavra1.Text = txtPalavra1.Text.ToUpper();
            txtPalavra2.Text = txtPalavra2.Text.ToUpper();

            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }

        private void btnInverte_Click(object sender, EventArgs e) // inverter (reverse)
        {
            string auxiliar = txtPalavra1.Text;
            char[] arr = auxiliar.ToCharArray(); 
            Array.Reverse(arr); 

            auxiliar = "";

            foreach (char cara in arr)
            {
                auxiliar = auxiliar + cara.ToString(); // pode usar +=
            }

            MessageBox.Show(auxiliar);
        }

        private void frmExercicio3_Load(object sender, EventArgs e)
        {

        }
    }
}
