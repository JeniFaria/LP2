﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            lblDados.Visible = true;
            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;

            if (txtNomeFunc.Text == String.Empty) //testa vazio
            {
                MessageBox.Show("O nome do funcionário");
            }
            else
            {
                if (!double.TryParse(txtSalBruto.Text, out salarioBruto)
                || !double.TryParse(txtNumFilho.Text, out numeroFilhos))
                {
                    MessageBox.Show("Salário bruto e número de filhos");
                }
                else
                {
                    if (salarioBruto <= 0)
                        MessageBox.Show("Salário bruto deve ser maior que 0");
                    else
                    {
                        if (salarioBruto <= 800.47)
                        {
                            txtAliquotaINSS.Text = "7.65%";
                            descontoINSS = (0.0765 * salarioBruto);
                        }
                        else if (salarioBruto <= 1050)
                        {
                            txtAliquotaINSS.Text = "8,65%";
                            descontoINSS = (0.0865 * salarioBruto);
                        }
                        else if (salarioBruto <= 1400.77)
                        {
                            txtAliquotaINSS.Text = "9.00%";
                            descontoINSS = (0.09 * salarioBruto);
                        }
                        else if (salarioBruto <= 2801.56)
                        {
                            txtAliquotaINSS.Text = "11.00%";
                            descontoINSS = (0.11 * salarioBruto);
                        }
                        else
                        {
                            txtAliquotaINSS.Text = "teto";
                            descontoINSS = 308.17;
                        }

                        txtDescontoINSS.Text = descontoINSS.ToString("N2");

                        if (salarioBruto <= 1257.12)
                            txtAliquotaIRPF.Text = "0";
                        else if (salarioBruto <= 2512.08)
                        {
                            txtAliquotaIRPF.Text = "15%";
                            descontoIRPF = (salarioBruto * 0.15);
                        }
                        else
                        {
                            txtAliquotaIRPF.Text = "27.5%";
                            descontoIRPF = (salarioBruto * 0.275);
                        }

                        txtDescontoIRPF.Text = descontoIRPF.ToString("N2");

                        if (numeroFilhos > 0)
                        {
                            if (salarioBruto <= 435.52)
                                salarioFamilia = (22.33 * numeroFilhos);
                            else if (salarioBruto <= 654.61)
                                salarioFamilia = (15.74 * numeroFilhos);
                            else
                                salarioFamilia = 0;
                        }
                        txtSalFamilia.Text = salarioFamilia.ToString("N2");
                        salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                        txtSalLiq.Text = salarioLiquido.ToString("N2");

                        lblDados.Text = "Os descontos do Salário " + (rbtnF.Checked ? "da Sra. " : "do Sr. ") + txtNomeFunc.Text +
                            " que é " + (ckbxCasado.Checked ? "Casado(a) " : "Solteiro(a) ") + "e que tem " + txtNumFilho.Text + " filho(s) são:";

                    }

                }
            }
        }
    }
}
