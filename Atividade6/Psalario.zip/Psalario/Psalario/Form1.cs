﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Descontos : Form
    {
        public Descontos()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;

            if (txtNomefunc.Text == string.Empty) //testando se a varíável está vazia
            {
                MessageBox.Show("Por favor preencher o nome");
            }
            else
            {
                if (!double.TryParse(txtSalarioBruto.Text, out salarioBruto) || !double.TryParse(txtNumFilhos.Text, out numeroFilhos)) // por o nupp ser numerico já eu não preciso fazer o tryparse, posso fazer  convertto.____
                {
                    MessageBox.Show("Salário Bruto e Número de Filhos devem ser numéricos");
                }
                else 
                {
                    if (salarioBruto <= 800.47) // Desconto INSS
                    {
                        txtInss.Text = "7.65%"; //atribuindo a String da alíquota a ser exibida na finaliação
                        descontoINSS = 0.0765 * salarioBruto;
                    }
                    else if (salarioBruto <= 1050)
                    {
                        txtInss.Text = "8.65%";
                        descontoINSS = 0.0865 * salarioBruto;
                    }
                    else if (salarioBruto <= 1400.77)
                    {
                        txtInss.Text = "9.00%";
                        descontoINSS = 0.09 * salarioBruto;
                    }
                    else if (salarioBruto <= 2801.56)
                    {
                        txtInss.Text = "11.00%";
                        descontoINSS = 0.11 * salarioBruto;
                    }
                    else
                    {
                        txtInss.Text = "Teto";
                        descontoINSS = 308.17;
                    }

                    txtDescInss.Text = descontoINSS.ToString("N2"); //convertendo para string e atribuindo para txtDescInss.Text o valor a ser descontado

                    //Desconto IRRPF
                    if (salarioBruto <= 1257.12)
                        txtIrrpf.Text = "0";
                    else if (salarioBruto <= 2512.08)
                    {
                        txtIrrpf.Text = "15.00%";
                        descontoIRPF = 0.15 * salarioBruto;
                    }
                    else
                    {
                        txtIrrpf.Text = "27.5%";
                        descontoIRPF = 0.27 * salarioBruto;
                    }

                    txtDescIrrpf.Text = descontoIRPF.ToString("N2");

                    //Salario Familia
                    if (numeroFilhos > 0)
                    {
                        if (salarioBruto <= 435.52)
                            salarioFamilia = (22.33 * numeroFilhos);
                        else if (salarioBruto <= 654.61)
                            salarioFamilia = (15.74 * numeroFilhos);
                        else
                            salarioFamilia = 0;
                    }

                    txtSalFamilia.Text = salarioFamilia.ToString("N2");

                    salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;

                    txtSalLiq.Text = salarioLiquido.ToString("N2");

                    lblDados.Text = "Os descontos do Salário " + (rbtnFeminino.Checked ? "da Sra." : "do Sr. ") + txtNomefunc.Text +
                        " que é " + (cbxCasado.Checked ? "Casado(a) " : "Solteiro(a) ") + "e que tem " + txtNumFilhos.Text + " filho(s) são:";
                }
            }


        }
    }
}
