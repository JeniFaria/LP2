﻿namespace Psalario
{
    partial class Descontos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblNumfilhos = new System.Windows.Forms.Label();
            this.lblInss = new System.Windows.Forms.Label();
            this.lblIRPF = new System.Windows.Forms.Label();
            this.lblSalfamilia = new System.Windows.Forms.Label();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.lblDescinss = new System.Windows.Forms.Label();
            this.lblDescirpf = new System.Windows.Forms.Label();
            this.txtNomefunc = new System.Windows.Forms.TextBox();
            this.txtInss = new System.Windows.Forms.TextBox();
            this.txtIrrpf = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.txtDescInss = new System.Windows.Forms.TextBox();
            this.txtDescIrrpf = new System.Windows.Forms.TextBox();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMasculino = new System.Windows.Forms.RadioButton();
            this.rbtnFeminino = new System.Windows.Forms.RadioButton();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.pnlEstadocivil = new System.Windows.Forms.Panel();
            this.cbxCasado = new System.Windows.Forms.CheckBox();
            this.lblDados = new System.Windows.Forms.Label();
            this.txtNumFilhos = new System.Windows.Forms.TextBox();
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.gbxSexo.SuspendLayout();
            this.pnlEstadocivil.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(12, 23);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(108, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do Funcionário";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(12, 57);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(67, 13);
            this.lblSalario.TabIndex = 1;
            this.lblSalario.Text = "Salário Bruto";
            // 
            // lblNumfilhos
            // 
            this.lblNumfilhos.AutoSize = true;
            this.lblNumfilhos.Location = new System.Drawing.Point(12, 93);
            this.lblNumfilhos.Name = "lblNumfilhos";
            this.lblNumfilhos.Size = new System.Drawing.Size(89, 13);
            this.lblNumfilhos.TabIndex = 2;
            this.lblNumfilhos.Text = "Número de Filhos";
            // 
            // lblInss
            // 
            this.lblInss.AutoSize = true;
            this.lblInss.Location = new System.Drawing.Point(19, 260);
            this.lblInss.Name = "lblInss";
            this.lblInss.Size = new System.Drawing.Size(73, 13);
            this.lblInss.TabIndex = 3;
            this.lblInss.Text = "Aliquota INSS";
            // 
            // lblIRPF
            // 
            this.lblIRPF.AutoSize = true;
            this.lblIRPF.Location = new System.Drawing.Point(19, 299);
            this.lblIRPF.Name = "lblIRPF";
            this.lblIRPF.Size = new System.Drawing.Size(72, 13);
            this.lblIRPF.TabIndex = 4;
            this.lblIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalfamilia
            // 
            this.lblSalfamilia.AutoSize = true;
            this.lblSalfamilia.Location = new System.Drawing.Point(19, 335);
            this.lblSalfamilia.Name = "lblSalfamilia";
            this.lblSalfamilia.Size = new System.Drawing.Size(76, 13);
            this.lblSalfamilia.TabIndex = 5;
            this.lblSalfamilia.Text = "Salário Família";
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Location = new System.Drawing.Point(19, 371);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(78, 13);
            this.lblSalLiq.TabIndex = 6;
            this.lblSalLiq.Text = "Salário Líquido";
            // 
            // lblDescinss
            // 
            this.lblDescinss.AutoSize = true;
            this.lblDescinss.Location = new System.Drawing.Point(296, 260);
            this.lblDescinss.Name = "lblDescinss";
            this.lblDescinss.Size = new System.Drawing.Size(81, 13);
            this.lblDescinss.TabIndex = 7;
            this.lblDescinss.Text = "Desconto INSS";
            // 
            // lblDescirpf
            // 
            this.lblDescirpf.AutoSize = true;
            this.lblDescirpf.Location = new System.Drawing.Point(296, 299);
            this.lblDescirpf.Name = "lblDescirpf";
            this.lblDescirpf.Size = new System.Drawing.Size(80, 13);
            this.lblDescirpf.TabIndex = 8;
            this.lblDescirpf.Text = "Desconto IRPF";
            // 
            // txtNomefunc
            // 
            this.txtNomefunc.Location = new System.Drawing.Point(126, 16);
            this.txtNomefunc.Name = "txtNomefunc";
            this.txtNomefunc.Size = new System.Drawing.Size(100, 20);
            this.txtNomefunc.TabIndex = 9;
            // 
            // txtInss
            // 
            this.txtInss.Location = new System.Drawing.Point(108, 253);
            this.txtInss.Name = "txtInss";
            this.txtInss.ReadOnly = true;
            this.txtInss.Size = new System.Drawing.Size(100, 20);
            this.txtInss.TabIndex = 12;
            // 
            // txtIrrpf
            // 
            this.txtIrrpf.Location = new System.Drawing.Point(108, 292);
            this.txtIrrpf.Name = "txtIrrpf";
            this.txtIrrpf.ReadOnly = true;
            this.txtIrrpf.Size = new System.Drawing.Size(100, 20);
            this.txtIrrpf.TabIndex = 13;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Location = new System.Drawing.Point(108, 328);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.ReadOnly = true;
            this.txtSalFamilia.Size = new System.Drawing.Size(100, 20);
            this.txtSalFamilia.TabIndex = 14;
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Location = new System.Drawing.Point(108, 364);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.ReadOnly = true;
            this.txtSalLiq.Size = new System.Drawing.Size(100, 20);
            this.txtSalLiq.TabIndex = 15;
            // 
            // txtDescInss
            // 
            this.txtDescInss.Location = new System.Drawing.Point(383, 253);
            this.txtDescInss.Name = "txtDescInss";
            this.txtDescInss.ReadOnly = true;
            this.txtDescInss.Size = new System.Drawing.Size(100, 20);
            this.txtDescInss.TabIndex = 16;
            // 
            // txtDescIrrpf
            // 
            this.txtDescIrrpf.Location = new System.Drawing.Point(383, 292);
            this.txtDescIrrpf.Name = "txtDescIrrpf";
            this.txtDescIrrpf.ReadOnly = true;
            this.txtDescIrrpf.Size = new System.Drawing.Size(100, 20);
            this.txtDescIrrpf.TabIndex = 17;
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbtnMasculino);
            this.gbxSexo.Controls.Add(this.rbtnFeminino);
            this.gbxSexo.Location = new System.Drawing.Point(244, 16);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Size = new System.Drawing.Size(95, 100);
            this.gbxSexo.TabIndex = 18;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbtnMasculino
            // 
            this.rbtnMasculino.AutoSize = true;
            this.rbtnMasculino.Location = new System.Drawing.Point(24, 61);
            this.rbtnMasculino.Name = "rbtnMasculino";
            this.rbtnMasculino.Size = new System.Drawing.Size(34, 17);
            this.rbtnMasculino.TabIndex = 1;
            this.rbtnMasculino.Text = "M";
            this.rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // rbtnFeminino
            // 
            this.rbtnFeminino.AutoSize = true;
            this.rbtnFeminino.Checked = true;
            this.rbtnFeminino.Location = new System.Drawing.Point(24, 38);
            this.rbtnFeminino.Name = "rbtnFeminino";
            this.rbtnFeminino.Size = new System.Drawing.Size(31, 17);
            this.rbtnFeminino.TabIndex = 0;
            this.rbtnFeminino.TabStop = true;
            this.rbtnFeminino.Text = "F";
            this.rbtnFeminino.UseVisualStyleBackColor = true;
            // 
            // btnVerificar
            // 
            this.btnVerificar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnVerificar.Location = new System.Drawing.Point(187, 183);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(115, 23);
            this.btnVerificar.TabIndex = 21;
            this.btnVerificar.Text = "Verificar Dados";
            this.btnVerificar.UseVisualStyleBackColor = false;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // pnlEstadocivil
            // 
            this.pnlEstadocivil.Controls.Add(this.cbxCasado);
            this.pnlEstadocivil.Location = new System.Drawing.Point(375, 23);
            this.pnlEstadocivil.Name = "pnlEstadocivil";
            this.pnlEstadocivil.Size = new System.Drawing.Size(108, 92);
            this.pnlEstadocivil.TabIndex = 22;
            // 
            // cbxCasado
            // 
            this.cbxCasado.AutoSize = true;
            this.cbxCasado.Checked = true;
            this.cbxCasado.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxCasado.Location = new System.Drawing.Point(24, 34);
            this.cbxCasado.Name = "cbxCasado";
            this.cbxCasado.Size = new System.Drawing.Size(62, 17);
            this.cbxCasado.TabIndex = 0;
            this.cbxCasado.Text = "Casado";
            this.cbxCasado.UseVisualStyleBackColor = true;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(19, 145);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(48, 13);
            this.lblDados.TabIndex = 23;
            this.lblDados.Text = "lblDados";
            // 
            // txtNumFilhos
            // 
            this.txtNumFilhos.Location = new System.Drawing.Point(126, 86);
            this.txtNumFilhos.Name = "txtNumFilhos";
            this.txtNumFilhos.Size = new System.Drawing.Size(100, 20);
            this.txtNumFilhos.TabIndex = 25;
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Location = new System.Drawing.Point(126, 50);
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioBruto.TabIndex = 26;
            // 
            // Descontos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(547, 414);
            this.Controls.Add(this.txtSalarioBruto);
            this.Controls.Add(this.txtNumFilhos);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.pnlEstadocivil);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.txtDescIrrpf);
            this.Controls.Add(this.txtDescInss);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtIrrpf);
            this.Controls.Add(this.txtInss);
            this.Controls.Add(this.txtNomefunc);
            this.Controls.Add(this.lblDescirpf);
            this.Controls.Add(this.lblDescinss);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.lblSalfamilia);
            this.Controls.Add(this.lblIRPF);
            this.Controls.Add(this.lblInss);
            this.Controls.Add(this.lblNumfilhos);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblNome);
            this.Name = "Descontos";
            this.Text = "Descontos";
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.pnlEstadocivil.ResumeLayout(false);
            this.pnlEstadocivil.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblNumfilhos;
        private System.Windows.Forms.Label lblInss;
        private System.Windows.Forms.Label lblIRPF;
        private System.Windows.Forms.Label lblSalfamilia;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.Label lblDescinss;
        private System.Windows.Forms.Label lblDescirpf;
        private System.Windows.Forms.TextBox txtNomefunc;
        private System.Windows.Forms.TextBox txtInss;
        private System.Windows.Forms.TextBox txtIrrpf;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.TextBox txtDescInss;
        private System.Windows.Forms.TextBox txtDescIrrpf;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.RadioButton rbtnMasculino;
        private System.Windows.Forms.RadioButton rbtnFeminino;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Panel pnlEstadocivil;
        private System.Windows.Forms.CheckBox cbxCasado;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.TextBox txtNumFilhos;
        private System.Windows.Forms.TextBox txtSalarioBruto;
    }
}

