﻿namespace Matrizes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxNomes = new System.Windows.Forms.ListBox();
            this.btnInverter = new System.Windows.Forms.Button();
            this.btnPrecoMercadorias = new System.Windows.Forms.Button();
            this.btnValTotal = new System.Windows.Forms.Button();
            this.btnArrayList = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnNomes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbxNomes
            // 
            this.lbxNomes.FormattingEnabled = true;
            this.lbxNomes.Location = new System.Drawing.Point(376, 58);
            this.lbxNomes.Name = "lbxNomes";
            this.lbxNomes.Size = new System.Drawing.Size(236, 264);
            this.lbxNomes.TabIndex = 0;
            // 
            // btnInverter
            // 
            this.btnInverter.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnInverter.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInverter.Location = new System.Drawing.Point(28, 58);
            this.btnInverter.Name = "btnInverter";
            this.btnInverter.Size = new System.Drawing.Size(143, 81);
            this.btnInverter.TabIndex = 1;
            this.btnInverter.Text = "Ler 20 números e inverter";
            this.btnInverter.UseVisualStyleBackColor = false;
            this.btnInverter.Click += new System.EventHandler(this.btnInverter_Click);
            // 
            // btnPrecoMercadorias
            // 
            this.btnPrecoMercadorias.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrecoMercadorias.Location = new System.Drawing.Point(200, 58);
            this.btnPrecoMercadorias.Name = "btnPrecoMercadorias";
            this.btnPrecoMercadorias.Size = new System.Drawing.Size(143, 81);
            this.btnPrecoMercadorias.TabIndex = 2;
            this.btnPrecoMercadorias.Text = "Ler Quant. e Preço Mercadorias";
            this.btnPrecoMercadorias.UseVisualStyleBackColor = true;
            this.btnPrecoMercadorias.Click += new System.EventHandler(this.btnPrecoMercadorias_Click);
            // 
            // btnValTotal
            // 
            this.btnValTotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValTotal.Location = new System.Drawing.Point(200, 154);
            this.btnValTotal.Name = "btnValTotal";
            this.btnValTotal.Size = new System.Drawing.Size(143, 72);
            this.btnValTotal.TabIndex = 3;
            this.btnValTotal.Text = "Variável Total";
            this.btnValTotal.UseVisualStyleBackColor = true;
            this.btnValTotal.Click += new System.EventHandler(this.btnValTotal_Click);
            // 
            // btnArrayList
            // 
            this.btnArrayList.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArrayList.Location = new System.Drawing.Point(28, 154);
            this.btnArrayList.Name = "btnArrayList";
            this.btnArrayList.Size = new System.Drawing.Size(143, 72);
            this.btnArrayList.TabIndex = 4;
            this.btnArrayList.Text = "ArrayList";
            this.btnArrayList.UseVisualStyleBackColor = true;
            this.btnArrayList.Click += new System.EventHandler(this.btnArrayList_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedia.Location = new System.Drawing.Point(28, 247);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(143, 72);
            this.btnMedia.TabIndex = 5;
            this.btnMedia.Text = "Média Alunos";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnNomes
            // 
            this.btnNomes.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNomes.Location = new System.Drawing.Point(200, 247);
            this.btnNomes.Name = "btnNomes";
            this.btnNomes.Size = new System.Drawing.Size(143, 72);
            this.btnNomes.TabIndex = 6;
            this.btnNomes.Text = "Nomes Pessoas";
            this.btnNomes.UseVisualStyleBackColor = true;
            this.btnNomes.Click += new System.EventHandler(this.btnNomes_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 437);
            this.Controls.Add(this.btnNomes);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnArrayList);
            this.Controls.Add(this.btnValTotal);
            this.Controls.Add(this.btnPrecoMercadorias);
            this.Controls.Add(this.btnInverter);
            this.Controls.Add(this.lbxNomes);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbxNomes;
        private System.Windows.Forms.Button btnInverter;
        private System.Windows.Forms.Button btnPrecoMercadorias;
        private System.Windows.Forms.Button btnValTotal;
        private System.Windows.Forms.Button btnArrayList;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnNomes;
    }
}

