﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Matrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInverter_Click(object sender, EventArgs e) // exercicio 01
        {
            int[] vetor = new int[20];
            string aux;
            for (var i=0; i<20; i++)
            {
                aux = Interaction.InputBox("Digite um número", "Entrada de dados");
                if(!Int32.TryParse(aux, out vetor [i]))
                {
                    MessageBox.Show("Dado inválido");
                    i--;
                }
            }
            aux = "";

            for (var i = 19; i >= 0; i--)
            {
                aux = aux + vetor[i] + "\n";
            }

            MessageBox.Show(aux);
        }

        private void btnPrecoMercadorias_Click(object sender, EventArgs e) // exercicio 02
        {
            double[] qtd = new double[10];
            double[] vlr = new double[10];
            double faturamento = 0;
            string aux = "";

            for (var i =0; i <10; i++)
            {
                aux = Interaction.InputBox("Digite quantidade de mercadoria" + (i + 1), "Entrada de quantidade");
                if (!double.TryParse(aux, out qtd[i]))
                {
                    MessageBox.Show("Quantidade inválida");
                    i--;
                }
                else
                {
                    while(vlr [i] <= 0)
                    {
                        aux = "";
                        aux = Interaction.InputBox("Digite o valor da mercadoria" + (i + 1), "Entrada preços");

                        if (!double.TryParse(aux, out vlr[i]))
                        {
                            MessageBox.Show("Preço inválido");
                        }
                    }
                }
                faturamento += qtd[i] * vlr[i];
            }
            MessageBox.Show(faturamento.ToString("N2"));

        }

        private void btnValTotal_Click(object sender, EventArgs e) // exercicio 03
        {
            string[] alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, total = 0;
            Int32 N = alunos.Length;

            for (I = 0; I< N-1; I++)
            {
            total += alunos[I].Length;
            MessageBox.Show(total.ToString("N2"));
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnMedia_Click(object sender, EventArgs e) // exercicio 05
        {
            double[,] notas = new double[20, 3];
            string aux = "";
            double media = 0;
            for (var i=0; i<20; i++)
                for(var j=0; j<3; j++)
                {
                    aux = Interaction.InputBox("Digite a nota" + (j + 1) + "aluno" + (i + 1), "entrada de dados");
                    if (!double.TryParse(aux, out notas[i, j]))
                    {
                        MessageBox.Show("Nota invalida");
                        j--;
                    }
                    else
                    {
                        if (!(notas[i, j] >= 0) && (notas[i, j] <= 10))
                        {
                            MessageBox.Show("Nota invalida");
                            i--;
                        }
                    }

                 media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;

                 MessageBox.Show("aluno" + (i + 1) + ":media" + media.ToString("N2"));
                    
                }
        }

        private void btnArrayList_Click(object sender, EventArgs e) // exercicio 04
        {
            ArrayList listaAlunos = new ArrayList();
            listaAlunos.Add("Ana");
            listaAlunos.Add("André");
            listaAlunos.Add("Débora");
            listaAlunos.Add("Fatima");
            listaAlunos.Add("Jão");
            listaAlunos.Add("Janete");
            listaAlunos.Add("Otávio");
            listaAlunos.Add("Marcelo");
            listaAlunos.Add("Pedro");
            listaAlunos.Add("Thais");

            listaAlunos.Remove("Otávio");

            foreach(string item in listaAlunos)
            {
                MessageBox.Show(item);
            }

        }

        private void btnNomes_Click(object sender, EventArgs e) // exercicio 06
        {
            int ra = 9;
            string[] Nomes = new string[ra];
            int[] tamanho = new int[ra];
            string aux;

            for (var i = 0; i < ra; i++)
            {
                Nomes[i] = Interaction.InputBox((i + 1) + " Digite um nome completo: ", "Entrada de dados nomes");
                tamanho[i] = Nomes[i].Trim().Length;
            }

            lbxNomes.Items.Clear();

            for (var i = 0; i < ra; i++)
            {
                aux = "O nome: " + Nomes[i] + " tem " + tamanho[i] + " caracteres " + "\n";
                lbxNomes.Items.Add(aux);
            }

        }

    }
}

