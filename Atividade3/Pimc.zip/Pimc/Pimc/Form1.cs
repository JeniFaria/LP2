﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
    

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double pesoAtual, altura, imc;

        
            if (txtAltura.Text.Contains("."))
            {
                txtAltura.Text = txtAltura.Text.Replace(".", ",");
            }

                if (Double.TryParse(txtAltura.Text, out altura) &&
                Double.TryParse(txtPesoAtual.Text, out pesoAtual))
            {
                if ((altura <= 0) || (pesoAtual <= 0))
                    MessageBox.Show("Erro: Os valores devem ser maiores que zero!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                else
                {
                    imc = pesoAtual / (Math.Pow(altura, 2));

                    imc = Math.Round(imc, 1);

                    txtResultado.Text = imc.ToString("N1");

                    if (imc < 18.5)
                        MessageBox.Show("Magreza");

                    else if (imc <= 24.9)
                        MessageBox.Show("Normal");

                    else if (imc <= 29.9)
                        MessageBox.Show("Sobrepeso");

                    else if (imc <= 39.9)
                        MessageBox.Show("Obesidade");
                    else
                        MessageBox.Show("Obesidade Grave");

                }
            }
            else
                MessageBox.Show("Erro: Os valores digitados são invalidos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPesoAtual.Clear();
            txtAltura.Clear();
            txtResultado.Clear();
            txtPesoAtual.Focus();
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
    }
}
